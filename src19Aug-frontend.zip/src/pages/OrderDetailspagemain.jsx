import React from 'react'

export default function OrderDetailspagemain() {
  return (
    <div>
      hellow OrderDetailspagemain
    </div>
  )
}
