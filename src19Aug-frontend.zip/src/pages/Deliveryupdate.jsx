
import React from 'react'

export default function Deliveryupdate() {
  return (
    <div>
      hellow
    </div>
  )
}
