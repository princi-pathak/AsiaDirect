import React from 'react'

export default function Whatssapicon() {
  return (
    <div>
      <a href="https://wa.me/27104480733" target="_blank" class="floating-whatsapp">
  <img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp" />
</a>

<a href="tel:+27104480733" class="floating-phone">
  <img src="https://img.icons8.com/color/48/000000/phone--v1.png" alt="Phone" />
</a>
    </div>
  )
}
