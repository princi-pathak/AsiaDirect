import React from 'react'
import Topbar from '../Topbar'
import Navbar from '../homepage/Navbar'
import Footer from '../homepage/Footer'
import Addfreight from './Addfreight'

export default function Addfreightmain() {
  return (
    <div>
      <Topbar />
      <Navbar />
      <Addfreight />
      <Footer />
    </div>
  )
}
