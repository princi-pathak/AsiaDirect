import React from 'react'
import image1 from '../../assestss/client1.png'
import image2 from '../../assestss/client2.png '
import image3 from '../../assestss/client-logo_05.png'
import image5 from '../../assestss/client5.png'
export default function OurClients() {
  return (
    <div>
      <section className="owlSec pt50 pb50 wow fadeInDown">
  <div className="container">
    <div className="row">
      <small>CLIENTS THAT TRUST US</small>
      <h2>OUR CLIENTS</h2>
    </div>
    <div className="row pt50">
      <div id="newSlider" className="owl-carousel">
        <div>
          <div className="owlHome">
            <img src={image1} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image2} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image3} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image2} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image5} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image5} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image3} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image2} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image1} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image2} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image2} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image5} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image3} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image2} alt="" />
          </div>
        </div>
        <div>
          <div className="owlHome">
            <img src={image1} alt="" />
          </div>
        </div>
        <div></div>
      </div>
    </div>
  </div>
</section>

    </div>
  )
}
