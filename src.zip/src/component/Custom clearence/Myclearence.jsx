import React from 'react'
import Topbar from '../Topbar'
import Navbar from '../homepage/Navbar'
import Footer from '../homepage/Footer'

export default function Myclearence() {
  return (
    <div>
      <Topbar />
      <Navbar />



      <Footer />
    </div>
  )
}
