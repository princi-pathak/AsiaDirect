import { createContext } from "react";

export const MyContext1 = createContext('')