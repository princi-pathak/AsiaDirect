import React from 'react'
import { Link } from 'react-router-dom'

export default function Uniovwersalpage() {
  return (
    <div>
     working on this page move to dashboard <Link to={"/Admin/dashboard"}>Dashboard</Link>
    </div>
  )
}
